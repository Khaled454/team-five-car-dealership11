package edu.psu.abington.ist.ist242;
/*
The functionality for the manager is to manage the inventory, So we don't need info like salary, local date, hire date, employees and etc unless we are giving him
the option to add employees but it is out of the scope of our project so I removed all not needed info. We also don't need first name and last
name unless we are printing the list of ADD or Hired employees or Printing the manager details. But let's keep it just to show that
We know how to use inheritance-Khaled 06/25/20
 */

import java.util.Scanner;

public class Manager extends Person{
    public Manager(String firstName, String lastName, String emailAddress, String phoneNumber, role role) {
        super (firstName, lastName, emailAddress, phoneNumber, role);
    }

    @Override
    public String getFirstName() {
        return super.getFirstName();
    }

    @Override
    public void setFirstName(String firstName) {
        super.setFirstName(firstName);
    }

    @Override
    public String getLastName() {
        return super.getLastName();
    }

    @Override
    public void setLastName(String lastName) {
        super.setLastName(lastName);
    }

    @Override
    public String getEmailAddress() {
        return super.getEmailAddress();
    }

    @Override
    public void setEmailAddress(String emailAddress) {
        super.setEmailAddress(emailAddress);
    }

    @Override
    public String getPhoneNumber() {
        return super.getPhoneNumber();
    }

    @Override
    public void setPhoneNumber(String phoneNumber) {
        super.setPhoneNumber(phoneNumber);
    }

    @Override
    public boolean hasRole(String role) {
        return super.hasRole(role);
    }

    @Override
    public role getRole() {
        return role;
    }

    @Override
    public void setRole(role role) {
        this.role = role;
    }

//Task to manage inventory

}
