package edu.psu.abington.ist.ist242;

import java.util.ArrayList;

public class WelcomeScreen {



        ArrayList<WelcomeScreen> carList = new ArrayList<>();// I dont understand this we might want to improve our welcome screen class- Khaled

    }
