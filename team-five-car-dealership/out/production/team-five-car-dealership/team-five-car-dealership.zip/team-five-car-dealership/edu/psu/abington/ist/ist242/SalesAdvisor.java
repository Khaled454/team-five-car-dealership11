package edu.psu.abington.ist.ist242;



public class SalesAdvisor extends Person{

    private int advisorId;

    public SalesAdvisor(String firstName, String lastName, String emailAddress, String phoneNumber, role role) {
        super(firstName, lastName, emailAddress, phoneNumber, role);


    }

    @Override
    public String getFirstName() {
        return super.getFirstName();
    }

    @Override
    public void setFirstName(String firstName) {
        super.setFirstName(firstName);
    }

    @Override
    public String getLastName() {
        return super.getLastName();
    }

    @Override
    public void setLastName(String lastName) {
        super.setLastName(lastName);
    }

    @Override
    public String getEmailAddress() {
        return super.getEmailAddress();
    }

    @Override
    public void setEmailAddress(String emailAddress) {
        super.setEmailAddress(emailAddress);
    }

    @Override
    public String getPhoneNumber() {
        return super.getPhoneNumber();
    }

    @Override
    public void setPhoneNumber(String phoneNumber) {
        super.setPhoneNumber(phoneNumber);
    }


    public int getAdvisorId() {
        return advisorId;
    }

    public void setAdvisorId(int _advisorId) {
        this.advisorId = _advisorId;
    }


    // TO-DO:
    //  print contact info for sales advisor to the customers
    //  class methods

}
