package edu.psu.abington.ist.ist242;
/*
Khaled Edits if removed commented out if changed will comment what was changed
06/25/20
 */
import java.util.ArrayList;
import java.util.Scanner;

public class Parts {
//Data members
    private int partID;//Added partID-Khaled
    private String partName;
    private int partNumber;//OR ID but in real life it is number
    private String partType;//So like under what category is this part. Example Shocks go under suspension category
    private double partPrice;


    // Constructor methods
    public Parts(int _PartID,String _partName, int _partNumber, String _partType,double _partPrice) {//Added double partPrice-Khaled
    this.partID=_PartID;
    this.partName=_partName;
    this.partNumber=_partNumber;
    this.partType=_partType;
    this.partPrice=_partPrice;
    }
    public int getPartID() {
        return partID;
    }

    public void setPartID(int partID) {
        this.partID = partID;
    }

    public Parts(String _partType) {
        this.partType = _partType;
    }

    public Parts(int _partNumber) {
        this.partNumber = _partNumber;
    }

   // Setters and getters
    public String getPartName() {
        return partName;
    }
    public void setPartName(String _partName) {
        this.partName = _partName;
    }


    public int getPartNumber() { return partNumber; }
    public void setPartNumber(int _partNumber) { this.partNumber =_partNumber; }


    public String getPartType() {
        return partType;
    }
    public void setPartType(String _partType) {
        this.partType = _partType;
    }

    public Double getPartPrice() {
        return partPrice;
    }//Added setters and getters for the price-Khaled
    public void setPartPrice(double _partPrice) {
        this.partPrice = _partPrice;
    }

    //Make an arraylist for the parts
    public static void listParts(ArrayList<Parts> pList) {
        for (Parts part : pList) {
            System.out.println("Part ID: " + part.getPartID());
            System.out.println("Part Name: "+part.getPartName());
            System.out.println("Part Number: " + part.getPartNumber());
            System.out.println("Part Type: " + part.getPartType());
            System.out.println("Part Price $: " + part.getPartPrice()+"\n");
        }
    }

    //  print parts
    /*
    public static void printParts(ArrayList<Parts> pList) { //If we have list parts isnt this the same. I dont think we need this Khaled
        for (Parts parts : pList) {
            System.out.printf(parts.getPartName()+ " " + parts.getPartNumber() + " " + parts.getPartType() + " (" + parts.getPartPrice() + ") \n");

        }
    }
*/
    // remove parts by ID number
    public static void removeParts(ArrayList<Parts> pList, int _partNumber) {
        for (Parts parts : pList) {
            if (parts.getPartNumber() == _partNumber) {
                pList.remove(parts);
            }
        }
    }
}
