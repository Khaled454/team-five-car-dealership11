package edu.psu.abington.ist.ist242;

// INITIAL WHEN READ:
// INITIAL IF REVISING CLASS:
// PLEASE ADD HEADER COMMENT FOR THIS CLASS :)
// We want to be able to add cusotmers like pizza shop-Khaled
// Print customers by manager maybe-Khaled

import java.util.ArrayList;

public class Customer extends Person{

    private boolean testDriveApproval;
    private String driversLicenseNum;
    private String address;
    private int customerID;

    public Customer(boolean testDriveApproval, int customerID, String driversLicenseNum, String firstName, String lastName, String emailAddress, String phoneNumber, String address, role role) {
        super(firstName,lastName,emailAddress,phoneNumber,role);
        this.customerID=customerID;
        this.address = address;
        this.testDriveApproval = testDriveApproval;
        this.driversLicenseNum = driversLicenseNum;
        this.role=role;
    }

    public boolean getTestDriveApproval() {
        return testDriveApproval;
    }

    public void setTestDriveApproval(boolean testDriveApproval) {
        this.testDriveApproval = testDriveApproval;
    }

    public String getDriversLicenseNum() {
        return driversLicenseNum;
    }

    public void setDriversLicenseNum(String driversLicenseNum) {
        this.driversLicenseNum = driversLicenseNum;
    }

    public String getAddress() {
        return address;
    }


    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String getFirstName() {
        return firstName;
    }

    @Override
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Override
    public String getLastName() {
        return lastName;
    }

    @Override
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public String getEmailAddress() {
        return emailAddress;
    }

    @Override
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }



    @Override
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }



    public static void printCustomer(ArrayList<Customer> cList) {       //  TO-DO : pass cust array through method
        for(Customer addCustomer : cList) {

        }
    }

}